package ceu.dam.psp.videojuegos.client;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ceu.dam.psp.videojuegos.exceptions.ApiException;
import ceu.dam.psp.videojuegos.exceptions.NotFoundException;
import ceu.dam.psp.videojuegos.model.Videojuego;
import tools.jackson.databind.ObjectMapper;

public class VideojuegoApiClientImpl implements VideojuegoApiClient{
private String urlBase; // Este atributo contendrá la URL base a la que hacer las peticiones
	
	public VideojuegoApiClientImpl(String uuidUrl) { 
		// El constructor recibe el identificador que ha generado crudcrud.com para nuestro API y construye la URL base
		urlBase = "https://crudcrud.com/api/" + uuidUrl + "/";
	}
	
	// TODO: Implementar el resto de métodos
	@Override
	public Videojuego findById(String id) throws NotFoundException, ApiException {
		return null;
	}

	@Override
	public List<Videojuego> findByAñoPublicacion(Integer año) throws NotFoundException, ApiException {
		return null;
	}

	@Override
	public String create(Videojuego videojuego) throws ApiException {
		return null;
	}

	@Override
	public void update(Videojuego videojuego) throws NotFoundException, ApiException {
	}

	@Override
	public void delete(String id) throws NotFoundException, ApiException {
	}

}