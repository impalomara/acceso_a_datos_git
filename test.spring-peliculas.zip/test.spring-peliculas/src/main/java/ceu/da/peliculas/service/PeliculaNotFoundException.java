package ceu.da.peliculas.service;

public class PeliculaNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4170554095589843150L;

	public PeliculaNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public PeliculaNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PeliculaNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PeliculaNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PeliculaNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
