package ceu.da.peliculas.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ceu.da.peliculas.model.PeliculaEntity;
import ceu.da.peliculas.repositories.PeliculaRepository;

@Service
public class PeliculasService {

	private final PeliculaRepository repo;

	PeliculasService(PeliculaRepository repo) {
		this.repo = repo;
	}

	public List<PeliculaEntity> consultarPeliculas() {
		return repo.findAll();
	}

	public PeliculaEntity consultarPelicula(Long id) throws PeliculaNotFoundException {
		Optional<PeliculaEntity> pelicula = repo.findById(id);
		if (pelicula.isPresent()) {
			return pelicula.get();
		}

		throw new PeliculaNotFoundException("No existe una pelicula con ese ID" + id);
		return pelicula.orElseThrow(() -> new PeliculaNotFoundException("No existe una película con ese ID: " + id));	}

	public PeliculaEntity crearPelicula(PeliculaEntity pelicula) {
		return repo.save(pelicula);
	}
	
	public PeliculaEntity actualisar(PeliculaEntity pelicula) {
		return repo.save(pelicula);
	}
	
	public void borrarPelicula(Long id) {
		repo.deleteById(id);
	}
	
}
