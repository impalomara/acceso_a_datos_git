package ceu.da.peliculas;

import ceu.da.peliculas.model.PeliculaEntity;
import ceu.da.peliculas.service.PeliculasService;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Application {

	private final PeliculasService peliculasService;

	Application(PeliculasService peliculasService) {
		this.peliculasService = peliculasService;
	}

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Application.class, args);

		// poc shft +alt + l

		PeliculasService service = run.getBean(PeliculasService.class);
		List<PeliculaEntity> result = service.consultarPeliculas();
		result.forEach(System.out::println);

	}

}
