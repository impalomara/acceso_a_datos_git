package ceu.dam.ad.orm.practicas.basicas.ejercicio1.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "temporadas")
public class Temporada {

	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private Long id;
	private Integer numero;
	
	@OneToMany(mappedBy = "temporada")
	@JoinColumn(name = "id_temporada")
	private List<Episodio> episodios;

}
