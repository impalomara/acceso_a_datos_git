package ceu.dam.ad.orm.practicas.basicas.ejercicio1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ceu.dam.ad.orm.practicas.basicas.ejercicio1.model.Serie;
import ceu.dam.ad.orm.practicas.basicas.ejercicio1.repository.SerieRepository;

@Service
@Transactional(rollbackFor = Exception.class)
public class SeriesServiceImpl implements SeriesService {

	private final SerieRepository repo;

	public SeriesServiceImpl(SerieRepository repo) {
		this.repo = repo;
	}

	public Serie consultarSerie(Long idSerie) throws SerieNotFoundException, SeriesServiceException {
		try {
			Optional<Serie> serie = repo.findWithAssociationsById(idSerie);
			if (serie.isEmpty()) {
				throw new SerieNotFoundException("No existe la serie con id: " + idSerie);
			}
			return serie.get();
		} catch (SerieNotFoundException e) {
			throw new SerieNotFoundException("No existe esa serie ", e);
		} catch (DataAccessException e) {
			throw new SeriesServiceException("Error al consultar la serie", e);
		}
	}

	public List<Serie> buscarSeries(String filtroDescripcion) throws SerieNotFoundException, SeriesServiceException {
		try {
			List<Serie> series = repo.findByDescripcionContainingIgnoreCase(filtroDescripcion);
			if (series.isEmpty()) {
				throw new SerieNotFoundException("No se encontraron series con la descripción: " + filtroDescripcion);
			}
			return series;
		} catch (SerieNotFoundException e) {
			throw e;
		} catch (Exception e) {
			throw new SeriesServiceException("Error al buscar las series", e);
		}
	}

	@Override
	@Transactional
	public Serie crearSerie(Serie serie) throws SeriesServiceException {
		try {
			return repo.save(serie);
		} catch (Exception e) {
			throw new SeriesServiceException("Error al crear la serie", e);
		}
	}

	@Override
	@Transactional
	public void elimnarSerie(Long idSerie) throws SeriesServiceException {
		try {
			repo.deleteById(idSerie);
		} catch (Exception e) {
			throw new SeriesServiceException("Error al eliminar la serie", e);
		}
	}

	@Override
	@Transactional
	public void actualizarSerie(Serie serie) throws SeriesServiceException {
		try {
			if (serie.getId() == null || !repo.existsById(serie.getId())) {
				throw new IllegalArgumentException("La serie que se quiere actualizar no existe");
			}
			repo.save(serie);
		} catch (DataAccessException e) {
			throw new SeriesServiceException("Error al actualizar la serie", e);
		}
	}
}
