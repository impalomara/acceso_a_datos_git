package ceu.dam.ad.orm.practicas.basicas.ejercicio1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ceu.dam.ad.orm.practicas.basicas.ejercicio1.model.Trailer;

public interface TrailerRepository
        extends JpaRepository<Trailer, Long> {

}