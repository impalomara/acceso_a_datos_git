package ceu.dam.ad.pedidos.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ceu.dam.ad.pedidos.model.PedidosArticulo;
import ceu.dam.ad.pedidos.model.Pedidos;

import java.util.List;
import java.util.Optional;


@Repository
public interface PedidoArticuloRepository extends JpaRepository<PedidosArticulo, Long>{
	 List<PedidosArticulo> findByIdPedido(Long idPedido);
}
