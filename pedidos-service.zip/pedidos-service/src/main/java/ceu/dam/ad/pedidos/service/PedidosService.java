package ceu.dam.ad.pedidos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import ceu.dam.ad.pedidos.model.Pedidos;
import ceu.dam.ad.pedidos.model.PedidosArticulo;
import ceu.dam.ad.pedidos.repository.PedidoArticuloRepository;
import ceu.dam.ad.pedidos.repository.PedidoRepository;

@Service
public class PedidosService implements PedidoService {

	private final PedidoRepository repo;
	private final PedidoArticuloRepository repoA;

	public PedidosService(PedidoRepository repo, PedidoArticuloRepository repoA) {
		this.repo = repo;
		this.repoA = repoA;
	}

	/**
	 * Recibe el id de un pedido y lo consulta en BBDD. Debe devolver el pedido con
	 * todos sus datos incluyendo sus artículos y sus totales. Lanza
	 * PedidoNotFoundException si el pedido no existe o PedidoException si hay un
	 * error.
	 * 
	 * @param idPedido
	 * @return
	 * @throws PedidoException
	 * @throws PedidoNotFoundException
	 */
	public Pedidos consultarPedido(Long idPedido) throws PedidoException, PedidoNotFoundException {
		try {
			Optional<Pedidos> pedidos = repo.findById(idPedido);

			if (pedidos.isEmpty()) {
				throw new PedidoNotFoundException("La id no encontrada");
			}

			Pedidos pedido = pedidos.get();
			List<PedidosArticulo> listapedidos = repoA.findByIdPedido(idPedido);
			pedido.setArticulos(listapedidos);
			return pedido;
		} catch (DataAccessException e) {
			throw new PedidoException("Error en la base de datos Pedidos", e);
		}
	}

	@Override
	public Pedidos crearPedido(Pedidos pedido) throws PedidoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Long> buscarPedidosArticulo(String codBarras) throws PedidoException, PedidoNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
