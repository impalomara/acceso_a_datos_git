package ceu.dam.ad.pedidos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ceu.dam.ad.pedidos.service.PedidoException;
import ceu.dam.ad.pedidos.service.PedidoNotFoundException;
import ceu.dam.ad.pedidos.service.PedidoService;
import ceu.dam.ad.pedidos.service.PedidosService;

@SpringBootApplication
public class PedidosServiceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(PedidosServiceApplication.class, args);

		PedidosService service = ctx.getBean(PedidosService.class);
		try {
			System.out.println(service.consultarPedido(1L));
		} catch (PedidoException | PedidoNotFoundException e) {
			e.printStackTrace();
		}

	}

}
