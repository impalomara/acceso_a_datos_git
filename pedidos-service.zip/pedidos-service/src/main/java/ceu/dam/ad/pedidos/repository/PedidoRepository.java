package ceu.dam.ad.pedidos.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ceu.dam.ad.pedidos.model.Pedidos;

@Repository
public interface PedidoRepository extends JpaRepository<Pedidos, Long>{
	
}
