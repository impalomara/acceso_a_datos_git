package client;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

public class ApiClient {

	private URI urlBase;
	private HttpClient httpClient;

	public ApiClient(String urlBase) {
		this.urlBase = URI.create(urlBase);
		httpClient = HttpClient.newHttpClient();
	}

	public String getCocheById(String id) throws  CochesApiException, CochesNotFoundException {
		try {
			HttpRequest request = HttpRequest.newBuilder(URI.create(urlBase + "/" + id)).GET().build();
			HttpResponse<String> response = httpClient.send(request, BodyHandlers.ofString());
			int status = response.statusCode();
			System.out.println("Codigo respuesta: " + status);
			if (status == 200) {
				return response.body();
			} else if (status == 400) {
				throw new CochesNotFoundException("No existe Coche");
			}
			throw new CochesApiException("Codigo respuesta erronea");

		} catch(IOException | InterruptedException e) {
			System.out.println("Error enviando peticion");
			e.printStackTrace();
			throw new CochesApiException("Erroes consultado API cohes", e);
		}
	}

}
