package client;

import java.io.IOException;

public class Test {
	public static void main(String[] args) throws IOException, InterruptedException, CochesApiException, CochesNotFoundException {
		ApiClient apiClient = new ApiClient("https://crudcrud.com/api/bc93d09c4cf5442796a158d1db6ef0f2/coches");
		String coche = apiClient.getCocheById("6abbfe4ae7869703e8e13d30");
		System.out.println(coche);
	}
}
