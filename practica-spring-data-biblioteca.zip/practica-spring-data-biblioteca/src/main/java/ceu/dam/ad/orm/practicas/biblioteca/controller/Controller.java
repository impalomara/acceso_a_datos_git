package ceu.dam.ad.orm.practicas.biblioteca.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ceu.dam.ad.orm.practicas.biblioteca.dto.response.ResponseCarnet;
import ceu.dam.ad.orm.practicas.biblioteca.dto.response.ResponseLibro;
import ceu.dam.ad.orm.practicas.biblioteca.dto.response.ResponsePrestamo;
import ceu.dam.ad.orm.practicas.biblioteca.dto.response.ResponseSinSociosPrestamo;
import ceu.dam.ad.orm.practicas.biblioteca.dto.response.ResponseSocio;
import ceu.dam.ad.orm.practicas.biblioteca.exception.BibliotecaException;
import ceu.dam.ad.orm.practicas.biblioteca.exception.NotFoundException;
import ceu.dam.ad.orm.practicas.biblioteca.model.Carnet;
import ceu.dam.ad.orm.practicas.biblioteca.model.Libro;
import ceu.dam.ad.orm.practicas.biblioteca.model.Prestamo;
import ceu.dam.ad.orm.practicas.biblioteca.model.Socio;
import ceu.dam.ad.orm.practicas.biblioteca.service.BibliotecaService;
import ch.qos.logback.core.model.Model;
import java.util.stream.Collectors;
@RestController
public class Controller {

	@Autowired
	BibliotecaService service;

	@PostMapping("/socio")
	public ResponseSocio altaSocio(Socio socio) throws BibliotecaException {
		if (socio.getDni() == null | socio.getNombre() == null | socio.getApellidos() == null) {
			throw new BibliotecaException("El dni, nombre y apellidos no tyienen que estar vacio");
		}
		Socio socioNuevo = service.altaSocio(socio);
		ModelMapper mapper = new ModelMapper();
		ResponseSocio response = mapper.map(socioNuevo, ResponseSocio.class);
		return response;
	}

	@GetMapping("/socio")
	public ResponseSocio consultarSocio(String dni) throws NotFoundException {
		Socio socio = service.consultarSocio(dni);
		ModelMapper mapper = new ModelMapper();
		ResponseSocio response = mapper.map(socio, ResponseSocio.class);
		return response;

	}

	@PostMapping("/libro")
	public ResponseLibro altaLibro(Libro libro) throws BibliotecaException {
		if (libro.getEjemplaresDisponibles() > 0) {
			System.out.println("Tiene que poner algun ejemplar");
		} else if (libro.getIsbn().length() != 13) {
			System.out.println("El ibsn del libro tiene que tener 13 de tamaño");
		} else if (libro.getAutor().isEmpty() | libro.getTitulo().isEmpty()) {
			System.out.println("El autor y el titulo no tienen que estar vacio");
		}
		Libro libroCreado = service.altaLibro(libro);
		ModelMapper mapper = new ModelMapper();
		ResponseLibro response = mapper.map(libroCreado, ResponseLibro.class);
		return response;

	}

	/** URL: /libro
	 * Recibimos todos los datos por los que queremos filtrar como requestParam. Ninguno es obligatorio
	 * Devolvemos todos los datos de los libros encontrados. */
	@GetMapping("/libro")
	public List<Libro> buscarLibros(@RequestParam(required = false) String isbn,
			@RequestParam(required = false) String titulo, @RequestParam(required = false) String autor,
			@RequestParam(required = false) String genero,
			@RequestParam(required = false) Integer ejemplaresDisponibles) {

		Libro ejemplo = new Libro();

		ejemplo.setIsbn(isbn);
		ejemplo.setTitulo(titulo);
		ejemplo.setAutor(autor);
		ejemplo.setGenero(genero);
		ejemplo.setEjemplaresDisponibles(ejemplaresDisponibles);

		return service.buscarLibros(ejemplo);
	}
	

	@PutMapping("/libro/xxx")
	public ResponsePrestamo prestarLibro(@RequestParam(required = false) String dniSocio, Long idLibro) throws NotFoundException, BibliotecaException{
		Prestamo PrestamoCreado = service.prestarLibro(dniSocio, idLibro);
		ModelMapper mapper = new ModelMapper();
		ResponsePrestamo response = mapper.map(PrestamoCreado, ResponsePrestamo.class);
		return response;
	}
	
	
	/** URL: /prestamo/XXX/YYY 
	 * XXX es año
	 * YYY es número de prestamo 
	 * */
	@PutMapping("/prestamo/{anio}/{numPrestamo}")
	public void devolverLibro(Integer anio, Integer numPrestamo) throws NotFoundException, BibliotecaException{
		service.devolverLibro(anio, numPrestamo);
		
	}
	
	/** URL: /socio/XXX/carnet 
	 * XXX es el dni del socio
	 * Devuelve todos los datos del carnet excepto el socio  */
	@PutMapping("/socio/{dniSocio}/carnet")
	public ResponseCarnet renovarCarnet(String dniSocio) throws NotFoundException, BibliotecaException{
		Carnet carnetCreado = service.renovarCarnet(dniSocio);
		ModelMapper mapper = new ModelMapper();
		ResponseCarnet response = mapper.map(carnetCreado, ResponseCarnet.class);
		return response;
	}

	/** URL: / socio/XXX/prestamos 
	 * Devuelve todos los datos del préstamo excepto socio
	 * */
	@GetMapping("socio/{dniSocio}/prestamos")
	public List<ResponseSinSociosPrestamo> consultarPrestamosActivos(@PathVariable String dniSocio) throws NotFoundException{
		List<Prestamo>prestamoActivos =service.consultarPrestamosActivos(dniSocio);
		
	    List<ResponseSinSociosPrestamo> response = prestamoActivos.stream()
	            .map(p -> mapper.map(p, ResponseSinSociosPrestamo.class))
	            .collect(Collectors.toList());

		return response;
	}

}
