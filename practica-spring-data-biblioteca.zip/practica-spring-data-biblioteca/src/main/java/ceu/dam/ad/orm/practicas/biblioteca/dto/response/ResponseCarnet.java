package ceu.dam.ad.orm.practicas.biblioteca.dto.response;

import java.time.LocalDate;
import java.util.UUID;


import ceu.dam.ad.orm.practicas.biblioteca.model.Socio;

public class ResponseCarnet {


	private UUID id;

	private LocalDate fechaAlta;
	private LocalDate fechaCaducidad;


}
