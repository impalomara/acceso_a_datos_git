package ceu.dam.ad.orm.practicas.biblioteca.model;

import java.util.List;

import jakarta.persistence.Id;
import lombok.Data;

@Data
public class Socio {
	@Id
	private String dni;
	private String nombre;
	private String apellidos;
	private Carnet carnet;
	private List<Prestamo> prestamos;

	

	@Override
	public String toString() {
		return "Socio [dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", carnet=" + carnet + ", prestamos="
				+ prestamos + "]";
	}

}
