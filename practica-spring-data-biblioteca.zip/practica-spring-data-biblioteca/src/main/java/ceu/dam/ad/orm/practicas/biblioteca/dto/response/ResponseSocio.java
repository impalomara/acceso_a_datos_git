package ceu.dam.ad.orm.practicas.biblioteca.dto.response;

import java.util.List;

import ceu.dam.ad.orm.practicas.biblioteca.model.Carnet;
import ceu.dam.ad.orm.practicas.biblioteca.model.Prestamo;
import lombok.Data;

@Data
public class ResponseSocio {

	private String dni;
	private String nombre;
	private String apellidos;
	private Carnet carnet;

}
