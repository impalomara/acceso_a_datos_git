package ceu.dam.ad.orm.practicas.biblioteca.model;

import java.time.LocalDate;
import java.util.UUID;

import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.Data;

@Data
public class Carnet {

	@Id
	private UUID id;
	@Id 
	@OneToOne
	private Socio socio;
	private LocalDate fechaAlta;
	private LocalDate fechaCaducidad;

	@Override
	public String toString() {
		return "Carnet [id=" + id + ", fechaAlta=" + fechaAlta + ", fechaCaducidad=" + fechaCaducidad + "]";
	}

}
