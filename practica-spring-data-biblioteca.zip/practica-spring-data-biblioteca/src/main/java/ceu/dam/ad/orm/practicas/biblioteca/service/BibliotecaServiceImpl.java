package ceu.dam.ad.orm.practicas.biblioteca.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;

import ceu.dam.ad.orm.practicas.biblioteca.exception.BibliotecaException;
import ceu.dam.ad.orm.practicas.biblioteca.exception.NotFoundException;
import ceu.dam.ad.orm.practicas.biblioteca.model.Carnet;
import ceu.dam.ad.orm.practicas.biblioteca.model.Libro;
import ceu.dam.ad.orm.practicas.biblioteca.model.Prestamo;
import ceu.dam.ad.orm.practicas.biblioteca.model.Socio;
import ceu.dam.ad.orm.practicas.biblioteca.repository.LibroRepository;
import ceu.dam.ad.orm.practicas.biblioteca.repository.SocioRepository;

public class BibliotecaServiceImpl implements BibliotecaService {

	private final SocioRepository repoSocio;
	private final LibroRepository repoLibro;

	public BibliotecaServiceImpl(SocioRepository repoSocio, LibroRepository repoLibro) {
		this.repoSocio = repoSocio;
		this.repoLibro = repoLibro;
	}

	@Override
	public Socio altaSocio(Socio socio) throws BibliotecaException {
		Optional<Socio> socioEncontrado = repoSocio.findById(socio.getDni());

		if (socioEncontrado.isEmpty()) {
			throw new BibliotecaException("No se en contro dicho dni");
		}
		Carnet carnet = new Carnet();
		carnet.setId(UUID.randomUUID());
		carnet.setFechaAlta(LocalDate.now());
		carnet.setFechaCaducidad(LocalDate.now().plusYears(1));
		socio.setCarnet(carnet);

		return socio;

	}

	@Override
	public Socio consultarSocio(String dni) throws NotFoundException {
		Socio socioEncontrado = repoSocio.findById(dni).orElseThrow(() -> new NotFoundException());
		return socioEncontrado;
	}

	@Override
	public Libro altaLibro(Libro libro) throws BibliotecaException {

		Libro liberoEncontrado = repoLibro.findByIsbn(libro.getIsbn());

		if (liberoEncontrado == null) {
			throw new BibliotecaException("No existe ese libro");
		}
		return liberoEncontrado;
	}

	@Override
	public List<Libro> buscarLibros(Libro ejemplo) {
		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues()
				.withMatcher("titulo", ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase())
				.withMatcher("isbn", ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase())
				.withMatcher("autor", ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase())
				.withMatcher("genero", ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase());
		Example<Libro> example = Example.of(ejemplo, matcher);
		return repoLibro.findAll(example);

	}

	@Override
	public Prestamo prestarLibro(String dniSocio, Long idLibro) throws NotFoundException, BibliotecaException {
		return null;
		// TODO: IMPLEMENTAR POR EL ALUMNO...
	}

	@Override
	public void devolverLibro(Integer anio, Integer numPrestamo) throws NotFoundException, BibliotecaException {
		// TODO: IMPLEMENTAR POR EL ALUMNO...
	}

	@Override
	public Carnet renovarCarnet(String dniSocio) throws NotFoundException, BibliotecaException {
		return null;
		// TODO: IMPLEMENTAR POR EL ALUMNO...
	}

	@Override
	public List<Prestamo> consultarPrestamosActivos(String dniSocio) throws NotFoundException {
		return null;
		// TODO: IMPLEMENTAR POR EL ALUMNO...
	}

}
