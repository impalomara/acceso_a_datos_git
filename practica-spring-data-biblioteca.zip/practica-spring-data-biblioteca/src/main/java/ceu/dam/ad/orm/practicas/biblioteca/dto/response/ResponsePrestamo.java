package ceu.dam.ad.orm.practicas.biblioteca.dto.response;

import java.time.LocalDate;

import ceu.dam.ad.orm.practicas.biblioteca.model.Libro;
import ceu.dam.ad.orm.practicas.biblioteca.model.Socio;
import lombok.Data;

@Data
public class ResponsePrestamo {

	private Integer anio;
	private Integer numPrestamo;
	private LocalDate fechaPrestamo;
	private LocalDate fechaDevolucion;



}
