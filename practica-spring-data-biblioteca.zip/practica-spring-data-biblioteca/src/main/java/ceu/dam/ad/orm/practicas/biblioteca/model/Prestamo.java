package ceu.dam.ad.orm.practicas.biblioteca.model;

import java.time.LocalDate;

import jakarta.persistence.Id;
import lombok.Data;

@Data
public class Prestamo {

	@Id
	private Integer anio;
	@Id
	private Integer numPrestamo;
	private Socio socio;
	private Libro libro;
	private LocalDate fechaPrestamo;
	private LocalDate fechaDevolucion;


	@Override
	public String toString() {
		return "Prestamo [anio=" + anio + ", numPrestamo=" + numPrestamo + ", libro=" + libro + ", fechaPrestamo="
				+ fechaPrestamo + ", fechaDevolucion=" + fechaDevolucion + "]";
	}

}
