package ceu.da.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsApiServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
