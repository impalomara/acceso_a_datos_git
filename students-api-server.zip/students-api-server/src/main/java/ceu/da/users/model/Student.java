package ceu.da.users.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import lombok.Data;

@Data
@Entity
public class Student {	
	
	private String id;
	private String dni;
	private String firstName;
	private String lastName;
	private String email;
	private LocalDate dateBirth;
	private String gender;
	private String program;
	private LocalDate createAt;
}
