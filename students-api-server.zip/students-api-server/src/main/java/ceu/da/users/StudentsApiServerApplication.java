package ceu.da.users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsApiServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsApiServerApplication.class, args);
	}

}
