package ceu.da.users.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import ceu.da.users.model.Student;
import ceu.da.users.service.StudentService;

@RestController
public class Controller {

	@Autowired
	 private StudentService service;
	
	

}
