package ceu.da.users.service;

import java.util.List;

import ceu.da.users.exception.StudentDuplicateException;
import ceu.da.users.exception.StudentNotFoundException;
import ceu.da.users.model.Student;

public interface StudentService {
	Student create(Student student) throws StudentDuplicateException;

	void remove(Long id) throws StudentNotFoundException;

	Student findById(Long id) throws StudentNotFoundException;

	List<Student> findAll() throws StudentNotFoundException;

	List<Student> findByAgeRange(Integer minAge, Integer maxAge);

	List<Student> search(FilterDto filter);
}
