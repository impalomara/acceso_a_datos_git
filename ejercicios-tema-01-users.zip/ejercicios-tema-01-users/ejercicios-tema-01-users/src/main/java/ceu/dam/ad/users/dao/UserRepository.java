package ceu.dam.ad.users.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ceu.dam.ad.users.model.User;
import repository.DatabaseConnection;

public class UserRepository {

	/** Debe insertar un usuario en BBDD. Devuelve el ID generado. */
	public Long insert(Connection conn, User user) throws SQLException {
		String sql = "INSERT INTO users (id,password,username, email,name,LastLoginDate,create_date  ) VALUES (?,?,?,?, ?, ?)";
		User usuario = new User();

		try (PreparedStatement stmt = conn.prepareStatement(sql);) {
			ResultSet rs = stmt.executeQuery();
			usuario.setCreatedDate(user.getCreatedDate());
			usuario.setId(user.getId());
			usuario.setEmail(user.getEmail());
			usuario.setLastLoginDate(user.getLastLoginDate());
			usuario.setPassword(user.getPassword());
			usuario.setUsername(user.getUsername());
			stmt.executeUpdate();
		}catch(SQLException e) {
			
		}
		return usuario.getId();

	}

	/**
	 * Debe consultar un usuario por su email y devolverlo. Si no existe, devolverá
	 * null
	 */
	public User getByEmail(Connection conn, String email) throws SQLException {
		String sql = "select * from user where email = ?";
		User usuario = null;
		
		try(PreparedStatement stmt = conn.prepareStatement(sql);){
				if (rs.next()) {
					ResultSet rs = stmt.executeQuery();
					usuario.setCreatedDate(rs.getDate(""));
					usuario.setId(rs.getLong("id"));
					usuario.setEmail(rs.getString("email"));
					usuario.setLastLoginDate(rs.Da);
					usuario.setPassword(rs.getString("password"));
					usuario.setUsername(rs.getString("username"));
				}
			}
		}catch() {
			
		}
		
	}

	/**
	 * Debe consultar un usuario por su ID y devolverlo. Si no existe, devolverá
	 * null. NOTA: no dupliques código
	 */
	public User getById(Connection conn, Long id) throws SQLException {
		return null;
	}

	/**
	 * Debe consultar un usuario por su email y devolverlo. Si no existe, devolverá
	 * null. NOTA: no dupliques código
	 */
	public User getByUserName(Connection conn, String userName) throws SQLException {
		return null;
	}

	/**
	 * Debe actualizar todos los datos de un usuario y devolver el número de
	 * registros actualizados.
	 */
	public Integer update(Connection conn, User user) throws SQLException {
		return null;
	}

}
