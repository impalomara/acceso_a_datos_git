package ceu.dam.ad.users.services;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;

import org.apache.commons.codec.digest.DigestUtils;

import ceu.dam.ad.users.dao.UserRepository;
import ceu.dam.ad.users.model.User;

public class UserServiceImpl extends Service implements UserService {
	private UserRepository repo;

	public UserServiceImpl() {
		repo = new UserRepository();
	}

	
	/** Recibe un usuario que trae indicado su username, email y password (sin cifrar). El servicio tendrá que:
	 * 1. Verificar que no existe usuario con ese email ni ese username. En caso contrario, lanzar DuplicateUserException
	 * 2. Registrar el usuario en BBDD completando su fecha de alta y cifrando su password con SHA3-256
	 * 3. Devolver el usuario con todos sus datos (incluyendo el ID) 
	 * 4. Si hay algún error, lanzará UserException con el origen
	 */
	public User createUser(User user) throws DuplicateUserException, UserException {
		try (Connection conn = abrirConexion()) {
			User usuario = new User();
			if (repo.getByEmail(conn, user.getEmail()) != null) {
				throw new DuplicateUserException("No existe ese correo electronico");
			}
			if (repo.getByUserName(conn, user.getUsername()) != null) {
				throw new DuplicateUserException("No existe ese usuario");
			}

			usuario.setLastLoginDate(user.getLastLoginDate());
			String contraseña = user.getPassword();
			String cifrado = DigestUtils.sha3_256Hex(contraseña);

			usuario.setEmail(user.getEmail());
			usuario.setPassword(cifrado);
			usuario.setUsername(user.getUsername());
			usuario.setLastLoginDate(LocalDate.now());
			repo.insert(conn, usuario);

			return usuario;
		} catch (SQLException e) {
			throw new UserException("Error conectado a BBDD", e);
		}
	}

	
	/** Recibe el id de un usuario, el password antiguo y el nuevo. Los dos sin cifrar. El servicio tendrá que:
	 * 1. Si el usuario no existe con ese ID, lanzar UserNotFoundException
	 * 2. Verificar que la nueva password no es igual a la antigua. Si lo es, lanzar UserUnauthorizedException
	 * 3. Verificar que la password antigua es correcta. Si no lo es, lanzar UserUnauthorizedException
	 * 4. Actualizar el nuevo password en el usuario cifrándolo previamente.
	 * 5. Si hay algún error, lanzará UserException con el origen
	 */
	public void changePassword(Long idUser, String oldPassword, String newPassword)
			throws UserNotFoundException, UserUnauthorizedException, UserException {
		try (Connection conn = abrirConexion()) {

			User usuario = repo.getById(conn, idUser);

			if (repo.getById(conn, idUser) == null) {
				throw new UserNotFoundException("No existe un usuario con ese ID");
			}

			if (oldPassword.equals(newPassword)) {
				throw new UserUnauthorizedException("La contraseña antigua es igual a la nueva");
			}

			String password = oldPassword;
			String cifrado = DigestUtils.sha3_224Hex(password);

			if (!usuario.getPassword().equals(cifrado)) {
				throw new UserUnauthorizedException("La contraseña antigua no es correcta");
			}

			String nuevoCifrado = DigestUtils.sha3_224Hex(newPassword);
			usuario.setPassword(nuevoCifrado);
			repo.update(conn, usuario);

		} catch (SQLException e) {
			throw new UserException("Error conectado a BBDD", e);
		}
	}

	
	/** Recibe un login que puede ser un username o un email, y el password sin cifrar. El servicio tendrá que:
	 * 1. Verificar que existe algún usuario con ese username o email. Si no es así, lanzar UserNotFoundException
	 * 2. Verificar que password es correcta. Si lo es, lanzar UserUnauthorizedException
	 * 3. Actualizamos fecha del último login. Si hay algún error aquí, registramos en el log, pero continuamos.
	 * 4. Devolver el usuario con todos sus datos que ha realizado el login.
	 * 5. Si hay algún error, lanzará UserException con el origen
	 */
	public User login(String login, String password)
			throws UserNotFoundException, UserUnauthorizedException, UserException {
		try (Connection conn = abrirConexion()) {
			User usuario = new User();
			if (repo.getByEmail(conn, login) == null || repo.getByUserName(conn, login) == null) {
				throw new UserNotFoundException("No existe en la base de datos ese email o usuario");
			}
			
			if (repo.getByUserName(conn, login).getPassword().equals(password)) {
				throw new UserUnauthorizedException("La contraseña es correcta");
			}
			
			if (repo.getByEmail(conn, login).getPassword().equals(password)) {
				throw new UserUnauthorizedException("La contraseña es correcta");
			}

			usuario.setLastLoginDate(LocalDate.now());
			repo.update(conn, usuario);
			return usuario;
		} catch (SQLException e) {
			throw new UserException("Error conectado a BBDD", e);

		}
	}

	
	/** Recibe el id de un usuario. El servicio tendrá que:
	 * 1. Si el usuario no existe con ese ID, lanzar UserNotFoundException
	 * 2. Devolver los datos completos del usuario
	 * 3. Si hay algún error, lanzará UserException con el origen
	 */
	public User getUser(Long idUser) throws UserNotFoundException, UserException {
		try (Connection conn = abrirConexion()) {
			User usuario = new User();
			if (repo.getById(conn, idUser) == null) {
				throw new UserNotFoundException("No existe usuario con ese ID");
			}
			return usuario;
		} catch (SQLException e) {
			throw new UserException("Error conectado a BBDD", e);
		}
	}

}
