package ceu.da.users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectoNuevo2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectoNuevo2Application.class, args);
	}

}
