package ceu.dam.ad.users.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ceu.dam.ad.users.model.User;
import java.util.List;
import java.util.Optional;


@Repository
public interface UserRepository extends JpaRepository<User, Long>{
	Optional findByEmail(String email);
	Optional findByUsername(String username);
	Optional findById(Long id);
}
