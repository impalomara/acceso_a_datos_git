package ceu.dam.ad.users.services;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;

import ceu.dam.ad.users.model.User;
import ceu.dam.ad.users.repository.UserRepository;
import ch.qos.logback.classic.joran.action.LoggerAction;

public class UserServiceImpl extends Service implements UserService {

	@Autowired
	private UserRepository repo;

	UserServiceImpl(UserRepository repo) {
		this.repo = repo;
	}

	/**
	 * Recibe un usuario que trae indicado su username, email, password (sin cifrar)
	 * y name. El servicio tendrá que: 1. Verificar que no existe usuario con ese
	 * email ni ese username. En caso contrario, lanzar DuplicateUserException 2.
	 * Registrar el usuario en BBDD completando su fecha de alta y cifrando su
	 * password con SHA3-256 3. Devolver el usuario con todos sus datos (incluyendo
	 * el ID) 4. Si hay algún error, lanzará UserException con el origen
	 */
	public User createUser(User user) throws DuplicateUserException, UserException {
		try {
		User usuario = new User();

		if (repo.findByEmail(user.getEmail()) != null) {
			throw new DuplicateUserException("Ya existe un usuario con ese correo electrónico");
		}
		if (repo.findByUsername(user.getUsername()) != null) {
			throw new DuplicateUserException("Ya existe un usuario con ese nombre de usuario");
		}

		usuario.setEmail(user.getEmail());
		usuario.setUsername(user.getUsername());
		usuario.setName(user.getName());
		usuario.setPassword(DigestUtils.sha3_256Hex(user.getPassword()));
		usuario.setCreatedDate(LocalDate.now());

		Optional id = repo.findById(id);
		if (id == null) {
			throw new UserException("Error creando al usuario. Obtuvimos ID null");
		}

		return repo.findById(id);

	}catch(SQLException e){
		throw new UserException("Error conectando a BBDD", e);
	}

	/**
	 * Recibe el id de un usuario, el password antiguo y el nuevo. Los dos sin
	 * cifrar. El servicio tendrá que: 1. Si el usuario no existe con ese ID, lanzar
	 * UserNotFoundException 2. Verificar que la nueva password no es igual a la
	 * antigua. Si lo es, lanzar UserUnauthorizedException 3. Verificar que la
	 * password antigua es correcta. Si no lo es, lanzar UserUnauthorizedException
	 * 4. Actualizar el nuevo password en el usuario cifrándolo previamente. 5. Si
	 * hay algún error, lanzará UserException con el origen
	 */
	public void changePassword(Long idUser, String oldPassword, String newPassword)
			throws UserNotFoundException, UserUnauthorizedException, UserException {
		try (Connection conn = abrirConexion()) {
			logger.info("Intentando cambiar la contraseña para el usuario con ID: " + idUser);

			User usuario = repo.getById(conn, idUser);
			if (usuario == null) {
				logger.warn("No se encontró el usuario con ID: " + idUser);
				throw new UserNotFoundException("No existe un usuario con ese ID");
			}

			if (oldPassword.equals(newPassword)) {
				logger.debug("La contraseña nueva es idéntica a la antigua para el usuario ID: " + idUser);
				throw new UserUnauthorizedException("La contraseña antigua es igual a la nueva");
			}

			String cifradoOld = DigestUtils.sha3_256Hex(oldPassword);
			if (!usuario.getPassword().equals(cifradoOld)) {
				logger.warn("La contraseña antigua no coincide para el usuario ID: " + idUser);
				throw new UserUnauthorizedException("La contraseña antigua no es correcta");
			}

			String nuevoCifrado = DigestUtils.sha3_256Hex(newPassword);
			usuario.setPassword(nuevoCifrado);
			repo.update(conn, usuario);

			logger.info("Contraseña actualizada exitosamente para el usuario con ID: {}", idUser);

		} catch (SQLException e) {
			logger.error("Error en BBDD al cambiar la contraseña", e);
			throw new UserException("Error conectado a BBDD", e);
		}
	}

	/**
	 * Recibe un login que puede ser un username o un email, y el password sin
	 * cifrar. El servicio tendrá que: 1. Verificar que existe algún usuario con ese
	 * username o email. Si no es así, lanzar UserNotFoundException 2. Verificar que
	 * password es correcta. Si lo es, lanzar UserUnauthorizedException 3.
	 * Actualizamos fecha del último login. Si hay algún error aquí, registramos en
	 * el log, pero continuamos. 4. Devolver el usuario con todos sus datos que ha
	 * realizado el login. 5. Si hay algún error, lanzará UserException con el
	 * origen
	 */
	public User login(String login, String password)
			throws UserNotFoundException, UserUnauthorizedException, UserException {
		try (Connection conn = abrirConexion()) {
			logger.info("Intento de login para: " + login);

			// Buscamos por email o por username
			User usuario = repo.getByEmail(conn, login);
			if (usuario == null) {
				usuario = repo.getByUserName(conn, login);
			}

			if (usuario == null) {
				logger.warn("No existe ningún usuario con el login: " + login);
				throw new UserNotFoundException("No existe en la base de datos ese email o usuario");
			}

			String passwordCifrada = DigestUtils.sha3_256Hex(password);
			if (!usuario.getPassword().equals(passwordCifrada)) {
				logger.warn("Contraseña incorrecta para el usuario: " + login);
				throw new UserUnauthorizedException("La contraseña no es correcta");
			}

			try {
				usuario.setLastLoginDate(LocalDate.now());
				repo.update(conn, usuario);
			} catch (Exception e) {
				logger.error("Error al actualizar la fecha del último login para el usuario: " + login, e);
			}

			logger.info("Login exitoso para el usuario: " + login);
			return usuario;

		} catch (SQLException e) {
			logger.error("Error en BBDD durante el proceso de login", e);
			throw new UserException("Error conectado a BBDD", e);
		}
	}

	/**
	 * Recibe el id de un usuario. El servicio tendrá que: 1. Si el usuario no
	 * existe con ese ID, lanzar UserNotFoundException 2. Devolver los datos
	 * completos del usuario 3. Si hay algún error, lanzará UserException con el
	 * origen
	 */
	public User getUser(Long idUser) throws UserNotFoundException, UserException {
		try (Connection conn = abrirConexion()) {
			logger.info("Buscando usuario por ID: " + idUser);

			User usuario = repo.getById(conn, idUser);
			if (usuario == null) {
				logger.warn("No se encontró ningún usuario con el ID: " + idUser);
				throw new UserNotFoundException("No existe usuario con ese ID");
			}

			logger.info("Usuario encontrado con éxito para ID: " + idUser);
			return usuario;

		} catch (SQLException e) {
			logger.error("Error en BBDD al obtener el usuario con ID: " + idUser, e);
			throw new UserException("Error conectado a BBDD", e);
		}
	}
}
