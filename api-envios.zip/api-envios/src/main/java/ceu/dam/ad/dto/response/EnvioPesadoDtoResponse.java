package ceu.dam.ad.dto.response;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class EnvioPesadoDtoResponse {

	private BigDecimal peso;
	private String estado;
}
