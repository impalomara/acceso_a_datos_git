package ceu.dam.ad.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "envios")
public final class Envio {

	@Id
	private Long id;
	@Column(name = "codigo_seguimiento")
	private String codigo;
	private LocalDate fechaRegistro;
	private BigDecimal pesoKg;
	private String estado;
	private BigDecimal temperaturaCelsius;

}
