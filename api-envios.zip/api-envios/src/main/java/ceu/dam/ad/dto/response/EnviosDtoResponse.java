package ceu.dam.ad.dto.response;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Data;

@Data
public class EnviosDtoResponse {

	private LocalDate fechaRegistro;
	private BigDecimal peso;
	private String estado;
	private BigDecimal temperaturaCelsius;

}
