package ceu.dam.ad.dto.request;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Data;

@Data
public class CreacionEnvioDtoRequest {
	private String codigo;
	private LocalDate fechaRegistro;
	private BigDecimal peso;
	private String estado;
	private BigDecimal temperaturaCelsius;

}
