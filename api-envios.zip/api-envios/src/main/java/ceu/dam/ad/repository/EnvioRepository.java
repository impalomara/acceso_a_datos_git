package ceu.dam.ad.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ceu.dam.ad.model.Envio;
import java.math.BigDecimal;


@Repository
public interface EnvioRepository  extends JpaRepository<Envio, Long>{
	List<Envio> findByTemperaturaCelsiusGreaterThan(BigDecimal TemperaturaCelsius);
	
	Envio findByCodigo(String codigo);
	
	Envio findByEstado(String estado);
}
