package ceu.dam.ad.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import ceu.dam.ad.exceptions.EnvioNoEncontradoException;
import ceu.dam.ad.exceptions.EstadoEnvioInvalidoException;
import ceu.dam.ad.exceptions.PoliticaTransporteInvalidaException;
import ceu.dam.ad.model.Envio;
import ceu.dam.ad.repository.EnvioRepository;

@Service
public class EnviosServiceImp implements EnviosService {
	private final EnvioRepository repo;

	public EnviosServiceImp(EnvioRepository repo) {
		this.repo = repo;
	}

	@Override
	public List<Envio> detectarEnviosEnRiesgoTermico(double limiteTemperatura) {
		List<Envio> riesgoTermico = repo.findByTemperaturaCelsiusGreaterThan(BigDecimal.valueOf(limiteTemperatura));
		return riesgoTermico;
	}

	@Override
	public long actualizarEstadoLoteReciente(List<String> codigos, String nuevoEstado)
			throws EnvioNoEncontradoException {
		long contador = 0;
		for (String codigo : codigos) {
			Envio envio = repo.findByCodigo(codigo);
			if (envio == null) {
				throw new EnvioNoEncontradoException();
			}
			envio.setEstado(nuevoEstado);
			contador++;
			repo.save(envio);
		}
		return contador;
	}

	@Override
	public Envio registrarNuevoEnvio(Envio nuevoEnvio)
			throws PoliticaTransporteInvalidaException, EstadoEnvioInvalidoException {
		Envio envio = repo.findByEstado(nuevoEnvio.getEstado());

		return envio;
	}

	@Override
	public Envio obtenerEnvioPesadoPrioritario() throws EstadoEnvioInvalidoException {

		return null;
	}

}
