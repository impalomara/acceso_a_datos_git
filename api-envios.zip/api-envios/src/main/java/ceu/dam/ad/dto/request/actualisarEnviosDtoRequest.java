package ceu.dam.ad.dto.request;

import java.util.List;

import lombok.Data;

@Data
public class actualisarEnviosDtoRequest {
	private List<String> codigo;
	private String nuevoEstado;
}
