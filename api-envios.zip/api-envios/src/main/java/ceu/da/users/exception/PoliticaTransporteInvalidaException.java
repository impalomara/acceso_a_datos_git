package ceu.da.users.exception;

public class PoliticaTransporteInvalidaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9045125273087785903L;

	public PoliticaTransporteInvalidaException() {
		// TODO Auto-generated constructor stub
	}

	public PoliticaTransporteInvalidaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PoliticaTransporteInvalidaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PoliticaTransporteInvalidaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PoliticaTransporteInvalidaException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
