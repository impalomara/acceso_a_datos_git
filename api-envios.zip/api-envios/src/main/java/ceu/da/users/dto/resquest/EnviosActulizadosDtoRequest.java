package ceu.da.users.dto.resquest;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.JoinColumn;
import lombok.Data;

@Data
public class EnviosActulizadosDtoRequest {
	private List<String> codigo;
	
	private String estado;
}
