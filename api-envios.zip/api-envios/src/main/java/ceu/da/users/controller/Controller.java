package ceu.da.users.controller;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.exception.DataException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import ceu.da.users.dto.response.EnviosDtoResponse;
import ceu.da.users.dto.resquest.EnviosActulizadosDtoRequest;
import ceu.da.users.model.Envio;
import ceu.da.users.service.EnviosService;

@RestController
public class Controller {

	@Autowired
	private EnviosService service;

	@GetMapping("/envios/RiesgoTermico/{limiteTemperatura}")
	public List<EnviosDtoResponse> detectarEnviosEnRiesgoTermico(@PathVariable Double limiteTemperatura) {

		if (limiteTemperatura <= -50 || limiteTemperatura >= 50) {
			throw new IllegalArgumentException("La temperatura estan fuera de rangos logiccos de control");
		}
		List<Envio> envio = service.detectarEnviosEnRiesgoTermico(limiteTemperatura);
		ModelMapper mapper = new ModelMapper();
		return envio.stream().map(e -> mapper.map(e, EnviosDtoResponse.class)).toList();
	}
	
	@PutMapping("/envios/estado")
	public Integer actualizarEstadoLoteReciente(@PathVariable EnviosActulizadosDtoRequest request) {
		return null;
	}

}
