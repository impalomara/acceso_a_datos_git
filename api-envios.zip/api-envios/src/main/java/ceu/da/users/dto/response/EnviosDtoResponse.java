package ceu.da.users.dto.response;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.JoinColumn;
import lombok.Data;

@Data
public class EnviosDtoResponse {
	
	@JoinColumn(name = "fecha_registro")
	private LocalDate fechaRegistro;
	
	@JoinColumn(name = "peso_kg")
	private BigDecimal peso;
	
	private String estado;
	
	@JoinColumn(name = "temperatura_celsius")
	private BigDecimal temperatura;
}
