package ceu.da.users.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import lombok.Data;

@Entity
@Data
public class Envio {
	@Id
	private Long id;
	
	@Column(name = "codigo_seguimiento")
	private String codigo;
	
	private LocalDate fechaRegistro;
	
	@Column(name = "peso_kg")
	private BigDecimal peso;
	
	private String estado;
	
	@Column(name = "temperatura_celsius")
	private BigDecimal temperatura;

}
