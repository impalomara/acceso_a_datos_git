package ceu.da.users.exception;

public class EstadoEnvioInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5498427186042279935L;

	public EstadoEnvioInvalidoException() {
		// TODO Auto-generated constructor stub
	}

	public EstadoEnvioInvalidoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EstadoEnvioInvalidoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public EstadoEnvioInvalidoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EstadoEnvioInvalidoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
